import os
import csv

# Folder & file path
attendance_folder = "Attendance"
attendance_file = os.path.join(attendance_folder, "Attendance.csv")

# Ensure folder exists
if not os.path.exists(attendance_folder):
    os.makedirs(attendance_folder)

# Overwrite file with correct headers
with open(attendance_file, "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["NAME", "DATE", "TIME", "PHOTO"])

print("✅ Attendance.csv has been reset with headers: NAME, DATE, TIME, PHOTO")
