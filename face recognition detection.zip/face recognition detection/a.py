import streamlit as st
import pandas as pd
import os

st.title("📋 Face Recognition Attendance System with Absent Feature")

attendance_file = "Attendance/Attendance.csv"
students_file = "students.csv"
photo_dir = "Attendance/photos"

if os.path.exists(attendance_file) and os.path.getsize(attendance_file) > 0:
    df = pd.read_csv(attendance_file)

    st.success("✅ Showing Attendance Records with Photos")

    # --- Present Students ---
    st.subheader("✅ Present Students")
    for _, row in df.iterrows():
        col1, col2 = st.columns([2, 1])
        with col1:
            st.write(f"**Name:** {row['NAME']}")
            st.write(f"**Date:** {row['DATE']}")
            st.write(f"**Time:** {row['TIME']}")
        with col2:
            photo_path = os.path.join(photo_dir, row["PHOTO"])
            if os.path.exists(photo_path):
                st.image(photo_path, width=100)
            else:
                st.write("No photo available")

    # --- Absent Students ---
    if os.path.exists(students_file):
        all_students = pd.read_csv(students_file)["NAME"].tolist()
        present_students = df["NAME"].tolist()
        absent_students = [s for s in all_students if s not in present_students]

        st.subheader("❌ Absent Students")
        if absent_students:
            for name in absent_students:
                st.write(f"- {name}")
        else:
            st.write("🎉 No one is absent!")
    else:
        st.warning("⚠️ students.csv not found. Cannot show absent list.")

else:
    st.warning("⚠️ No attendance records found. Run test.py and press 'q'.")
