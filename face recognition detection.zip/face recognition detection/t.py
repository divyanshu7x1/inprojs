from sklearn.neighbors import KNeighborsClassifier
import cv2
import pickle
import numpy as np
import os
import csv
import time
from datetime import datetime

# Open webcam
video = cv2.VideoCapture(0)
facedetect = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

# Load training data
with open('data/names.pkl', 'rb') as f:
    LABELS = pickle.load(f)
with open('data/faces_data.pkl', 'rb') as f:
    FACES = pickle.load(f)

# Ensure equal length
min_len = min(len(FACES), len(LABELS))
FACES, LABELS = FACES[:min_len], LABELS[:min_len]

# Train KNN classifier
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(FACES, LABELS)

# Paths
ATTENDANCE_FILE = "Attendance/Attendance.csv"
PHOTO_DIR = "Attendance/photos"
if not os.path.exists(PHOTO_DIR):
    os.makedirs(PHOTO_DIR)

last_crop, attendance = None, None

while True:
    ret, frame = video.read()
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = facedetect.detectMultiScale(gray, 1.3, 5)

    for (x, y, w, h) in faces:
        crop_img = frame[y:y+h, x:x+w, :]
        resized_img = cv2.resize(crop_img, (50, 50)).flatten().reshape(1, -1)
        output = knn.predict(resized_img)

        ts = time.time()
        date = datetime.fromtimestamp(ts).strftime("%d-%m-%Y")
        timestamp = datetime.fromtimestamp(ts).strftime("%H-%M-%S")

        cv2.rectangle(frame, (x, y), (x+w, y+h), (50, 50, 255), 2)
        cv2.putText(frame, str(output[0]), (x, y-15),
                    cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 1)

        last_crop = crop_img
        attendance = [str(output[0]), date, timestamp]

    cv2.imshow("Face Recognition Attendance", frame)

    if cv2.waitKey(1) == ord('q') and attendance is not None and last_crop is not None:
        # Load existing
        existing = []
        with open(ATTENDANCE_FILE, "r") as f:
            reader = csv.reader(f)
            next(reader)
            existing = list(reader)

        # Prevent duplicate same NAME+DATE
        already = any(row[0] == attendance[0] and row[1] == attendance[1] for row in existing)

        if not already:
            # Save photo
            photo_filename = f"{attendance[0]}_{attendance[1]}_{attendance[2]}.jpg"
            photo_path = os.path.join(PHOTO_DIR, photo_filename)
            cv2.imwrite(photo_path, last_crop)

            # Save row
            attendance_with_photo = [attendance[0], attendance[1], attendance[2], photo_filename]
            with open(ATTENDANCE_FILE, "a", newline="") as f:
                writer = csv.writer(f)
                writer.writerow(attendance_with_photo)

            print("✅ Attendance saved:", attendance_with_photo)
        else:
            print("⚠️ Already marked:", attendance[0], "on", attendance[1])
        break

video.release()
cv2.destroyAllWindows()
